export class StudentModel{
    id:number=0;
    name:string= "";
    class?:string;
    email?:string;
    mobile?:string;

}